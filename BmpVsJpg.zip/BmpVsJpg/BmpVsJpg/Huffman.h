
#ifndef HUFFMAN_H__
#define HUFFMAN_H__

extern const int gWTree[][2];
extern const int gBTree[][2];
extern const int gTwoTree[][2];
extern const unsigned char gBackward[256];

#endif	// HUFFMAN_H__